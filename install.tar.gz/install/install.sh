#!/bin/bash
IPAddress=`curl whatismyip.akamai.com`;
python install.py $IPAddress
sed -i 's/ajax.googleapis.com\/ajax\/libs\/angularjs\//code.angularjs.org\//g' /usr/local/CyberCP/baseTemplate/templates/baseTemplate/index.html
sed -i 's/ajax.googleapis.com\/ajax\/libs\/angularjs\//code.angularjs.org\//g' /usr/local/CyberCP/loginSystem/templates/loginSystem/login.html
